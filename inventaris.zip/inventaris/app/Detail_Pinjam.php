<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Detail_Pinjam extends Model
{
     protected $table ='detail_pinjaman';
    protected $fillable =['id','inventaris','jumlah'];
}
