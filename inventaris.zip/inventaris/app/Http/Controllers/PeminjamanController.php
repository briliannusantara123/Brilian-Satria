<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PeminjamanController extends Controller
{
     public function index()
    {
        $data_peminjaman=\App\Peminjaman::all();
        $pegawai= \App\Pegawai::all();
        return view('peminjaman.index',['data_peminjaman' => $data_peminjaman,'pegawai' => $pegawai]);
    }
    public function create(Request $request)
    {
        \App\Peminjaman::create($request->all());
        return redirect('/peminjaman')->with('sukses','data berhasil disimpan');
    }
    public function edit($id)
    {
        $peminjaman = \App\Peminjaman::find($id);
        $pegawai= \App\Pegawai::all();
        return view('peminjaman/edit',['peminjaman' =>$peminjaman,'pegawai' => $pegawai]);
    }
    public function update(Request $request,$id)
    {
        $peminjaman = \App\Peminjaman::find($id);
        $peminjaman->update($request->all());
        return redirect('/peminjaman');
    }
    public function delete($id)
    {
        $peminjaman = \App\Peminjaman::find($id);
        $peminjaman->delete($peminjaman);
        return redirect('/peminjaman');
    }}
