<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RuangController extends Controller
{
     public function index()
    {
        $data_ruang=\App\Ruang::all();
        return view('ruang.index',['data_ruang' => $data_ruang]);
    }
    public function create(Request $request)
    {
        \App\Ruang::create($request->all());
        return redirect('/ruang')->with('sukses','data berhasil disimpan');
    }
    public function edit($id)
    {
        $ruang = \App\Ruang::find($id);
        return view('ruang/edit',['ruang' =>$ruang]);
    }
    public function update(Request $request,$id)
    {
        $ruang = \App\Ruang::find($id);
        $ruang->update($request->all());
        return redirect('/ruang');
    }
    public function delete($id)
    {
        $ruang = \App\Ruang::find($id);
        $ruang->delete($ruang);
        return redirect('/ruang');
    }}
