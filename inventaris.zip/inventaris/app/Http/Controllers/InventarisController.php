<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InventarisController extends Controller
{
     public function index()
    {
        $data_inventaris=\App\Inventaris::all();
        $jenis= \App\Jenis::all();
        $ruang= \App\Ruang::all();
        $petugas= \App\Petugas::all();
        return view('inventaris.index',['data_inventaris' => $data_inventaris,'jenis' => $jenis,'ruang'=>$ruang,'petugas'=>$petugas]);
    }
    public function create(Request $request)
    {
        \App\Inventaris::create($request->all());
        return redirect('/inventaris')->with('sukses','data berhasil disimpan');
    }
    public function edit($id)
    {
        $inventaris = \App\Inventaris::find($id);
        $jenis= \App\Jenis::all();
        $ruang= \App\Ruang::all();
        $petugas= \App\Petugas::all();
        return view('inventaris/edit',['inventaris' =>$inventaris,'jenis' => $jenis,'ruang'=>$ruang,'petugas'=>$petugas]);
    }
    public function update(Request $request,$id)
    {
        $inventaris = \App\Inventaris::find($id);
        $inventaris->update($request->all());
        return redirect('/inventaris');
    }
    public function delete($id)
    {
        $inventaris = \App\Inventaris::find($id);
        $inventaris->delete($inventaris);
        return redirect('/inventaris');
    }
}
