<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LevelController extends Controller
{
     public function index()
    {
        $data_level=\App\Level::all();
        return view('level.index',['data_level' => $data_level]);
    }
    public function create(Request $request)
    {
        \App\Level::create($request->all());
        return redirect('/level')->with('sukses','data berhasil disimpan');
    }
    public function edit($id)
    {
        $level = \App\Level::find($id);
        return view('level/edit',['level' =>$level]);
    }
    public function update(Request $request,$id)
    {
        $level = \App\Level::find($id);
        $level->update($request->all());
        return redirect('/level');
    }
    public function delete($id)
    {
        $level = \App\Level::find($id);
        $level->delete($level);
        return redirect('/level');
    }}
