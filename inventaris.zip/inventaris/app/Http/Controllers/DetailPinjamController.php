<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DetailPinjamController extends Controller
{
     public function index()
    {
        $data_detail=\App\Detail_Pinjam::all();
        $inventaris= \App\Inventaris::all();
        return view('detail.index',['data_detail' => $data_detail,'inventaris' => $inventaris]);
    }
    public function create(Request $request)
    {
        \App\Siswa::create($request->all());
        return redirect('/detail')->with('sukses','data berhasil disimpan');
    }
    public function edit($id)
    {
        $siswa = \App\Detail_Pinjam::find($id);
        $inventaris= \App\Inventaris::all();
        return view('detail/edit',['detail' =>$detail,'inventaris' => $inventaris]);
    }
    public function update(Request $request,$id)
    {
        $siswa = \App\Detail_Pinjam::find($id);
        $siswa->update($request->all());
        return redirect('/detail');
    }
    public function delete($id)
    {
        $detail = \App\Detail_Pinjam::find($id);
        $detail->delete($detail);
        return redirect('/detail');
    }}
