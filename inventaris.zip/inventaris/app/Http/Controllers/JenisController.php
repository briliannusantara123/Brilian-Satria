<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JenisController extends Controller
{
     public function index()
    {
        $data_jenis=\App\Jenis::all();
        return view('jenis.index',['data_jenis' => $data_jenis]);
    }
    public function create(Request $request)
    {
        \App\Jenis::create($request->all());
        return redirect('/jenis')->with('sukses','data berhasil disimpan');
    }
    public function edit($id)
    {
        $jenis = \App\Jenis::find($id);
        return view('jenis/edit',['jenis' =>$jenis]);
    }
    public function update(Request $request,$id)
    {
        $jenis = \App\Jenis::find($id);
        $jenis->update($request->all());
        return redirect('/jenis');
    }
    public function delete($id)
    {
        $jenis = \App\Jenis::find($id);
        $jenis->delete($jenis);
        return redirect('/jenis');
    }}
