<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PetugasController extends Controller
{
     public function index()
    {
        $data_petugas=\App\Petugas::all();
        $level= \App\Level::all();
        return view('petugas.index',['data_petugas' => $data_petugas,'level' => $level]);
    }
    public function create(Request $request)
    {
        \App\Petugas::create($request->all());
        return redirect('/petugas')->with('sukses','data berhasil disimpan');
    }
    public function edit($id)
    {
        $petugas = \App\Petugas::find($id);
        $level= \App\Level::all();
        return view('petugas/edit',['petugas' =>$petugas,'level' => $level]);
    }
    public function update(Request $request,$id)
    {
        $petugas = \App\Petugas::find($id);
        $petugas->update($request->all());
        return redirect('/petugas');
    }
    public function delete($id)
    {
        $petugas = \App\Petugas::find($id);
        $petugas->delete($petugas);
        return redirect('/petugas');
    }}
