<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Inventaris extends Model
{
     protected $table ='inventaris';
    protected $fillable =['id','nama','kondisi','keterangan','jumlah','jenis','tanggal_register','ruang','petugas'];
}
