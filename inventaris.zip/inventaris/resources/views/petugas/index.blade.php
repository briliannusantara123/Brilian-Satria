							
@extends('layouts.master')

@section('content')
	
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Data Buku
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="/buku">Buku</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="/penerbit">Penerbit</a>
        </div>
      </li>
    </form>
  </div>
</nav>
	<div class="container">
		<div class="row">
			<div class="col-6">
			<h3 class="panel-title">Data petugas</h3>
		</div>
		<div class="col-6">
			
		</div>
					<div class="col-md-12">
						<div class="panel">
				
							<div class="panel-heading">
									
									<div class="right">
									
									</div>
									
								</div>
								<br>	
								<br>	
									<br>	
								<div class="panel-body">
									<button type="button" class="btn btn-primary float-right btn-sm" data-toggle="modal" data-target="#exampleModal">Masukan Data Petugas</button>
									<table class="table table-hover">
										<thead>
											<tr>
												<th>Nama Petugas</th>
												<th>Username</th>
												<th>Password</th>
                        <th>level</th>
											</tr>
										</thead>
										<tbody>
											@foreach($data_petugas as $petugas)
											<tr>
												<td>{{$petugas->petugas}}</td>
												<td>{{$petugas->username}}</td>
												<td>{{$petugas->password}}</td>
                        <td>{{$petugas->level}}</td>
												<td><a href="/petugas/{{$petugas->id}}/edit" class="btn btn-warning btn-sm">Edit</a>
													<a href="/petugas/{{$petugas->id}}/delete" class="btn btn-danger btn-sm" onclick ="return confirm('yakin akan menghapus data?')">Hapus</a>
												</td>
											</tr>
											@endforeach
										</tbody>
									</table>
								</div>
							</div>
						</div>
						</div>
	</div>
						<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Petugas</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
				        <form action="/petugas/create" method="POST">
				      {{csrf_field()}}
  
  <div class="form-group">
    <label for="exampleInputEmail1">Nama Petugas</label>
    <input name="petugas"type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">

  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Username</label>
    <input name="username"type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Password</label>
    <textarea name="password"type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"></textarea>
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Level</label>
    <select name="level" class="form-control" id="exampleFormControlSelect1">
      @foreach($level as $level)
      <option value="{{$level->level}}">{{$level->level}}</option>
      @endforeach
    </select>
  </div>
<div class="modal-footer">
	<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	<button type="submit" class="btn btn-primary">Submit</button>


</form>

@endsection
							