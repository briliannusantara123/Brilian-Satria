							
@extends('layouts.master')

@section('content')
	
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Data Buku
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="/buku">Buku</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="/penerbit">Penerbit</a>
        </div>
      </li>
    </form>
  </div>
</nav>
	<div class="container">
		<div class="row">
			<div class="col-6">
			<h3 class="panel-title">Data Jenis</h3>
		</div>
		<div class="col-6">
			
		</div>
					<div class="col-md-12">
						<div class="panel">
				
							<div class="panel-heading">
									
									
									
								</div>
                <br>  

								<div class="panel-body">

                  
									<table class="table table-hover">
                    <button type="button" class="btn btn-primary float-right btn-sm" data-toggle="modal" data-target="#exampleModal">Masukan Data Jenis</button>
										<thead>
											<tr>
												<th>Jenis</th>
												<th>Keterangan</th>
												<th>Aksi</th>
											</tr>
										</thead>
										<tbody>
											@foreach($data_jenis as $jenis)
											<tr>
												<td>{{$jenis->jenis}}</td>
												<td>{{$jenis->keterangan}}</td>
												<td><a href="/jenis/{{$jenis->id}}/edit" class="btn btn-warning btn-sm">Edit</a>
													<a href="/jenis/{{$jenis->id}}/delete" class="btn btn-danger btn-sm" onclick ="return confirm('yakin akan menghapus data?')">Hapus</a>
												</td>
											</tr>
											@endforeach
										</tbody>
									</table>
								</div>
							</div>
						</div>
						</div>
	</div>
						<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Jenis</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
				        <form action="/jenis/create" method="POST">
				      {{csrf_field()}}
  
  <div class="form-group">
    <label for="exampleInputEmail1">Jenis</label>
    <input name="jenis"type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">

  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Keterangan</label>
    <textarea name="keterangan"type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"></textarea>
  </div>
  
<div class="modal-footer">
	<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	<button type="submit" class="btn btn-primary">Submit</button>


</form>

@endsection