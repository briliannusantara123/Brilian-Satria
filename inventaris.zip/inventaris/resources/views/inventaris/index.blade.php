							
@extends('layouts.master')

@section('content')
		<div class="row">
			<div class="col-6">
			<h3 class="panel-title">Data Inventaris</h3>
		</div>
		<div class="col-6">
			
		</div>
					<div class="col-md-12">

						<div class="panel">
				
							<div class="panel-heading">
									
									<div class="right">
									
									</div>
									
								</div>
                <br>
                <br>
                <br>
								<div class="panel-body">
                  <button type="button" class="btn btn-primary float-right btn-sm" data-toggle="modal" data-target="#exampleModal">Masukan Data inventaris</button>
									<table class="table table-hover">
										<thead>
											<tr>
												<th>Nama</th>
												<th>Kondisi</th>
												<th>Keterangan</th>
                        <th>Jumlah</th>
                        <th>Jenis</th>
                        <th>Tanggal Register</th>
                        <th>Ruang</th>
                        <th>Petugas</th>
												<th>Aksi</th>
											</tr>
										</thead>
										<tbody>
											@foreach($data_inventaris as $inventaris)
											<tr>
												<td>{{$inventaris->nama}}</td>
												<td>{{$inventaris->kondisi}}</td>
												<td>{{$inventaris->keterangan}}</td>
                        <td>{{$inventaris->jumlah}}</td>
                        <td>{{$inventaris->jenis}}</td>
                        <td>{{$inventaris->tanggal_register}}</td>
                        <td>{{$inventaris->ruang}}</td>
                        <td>{{$inventaris->petugas}}</td>
												<td><a href="/inventaris/{{$inventaris->id}}/edit" class="btn btn-warning btn-sm">Edit</a>
													<a href="/inventaris/{{$inventaris->id}}/delete" class="btn btn-danger btn-sm" onclick ="return confirm('yakin akan menghapus data?')">Hapus</a>
												</td>
											</tr>
											@endforeach
										</tbody>
									</table>
								</div>
							</div>
						</div>
						</div>
	
						<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Inventaris</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
				        <form action="/inventaris/create" method="POST">
				      {{csrf_field()}}
  
  <div class="form-group">
    <label for="exampleInputEmail1">Nama</label>
    <input name="nama"type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">

  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Kondisi</label>
    <input name="kondisi"type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Keterangan</label>
    <textarea name="keterangan"type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"></textarea>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Jumlah</label>
    <input name="jumlah"type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Jenis</label>
    <select name="jenis" class="form-control" id="exampleFormControlSelect1">
      @foreach($jenis as $jenis)
      <option value="{{$jenis->jenis}}">{{$jenis->jenis}}</option>
      @endforeach
    </select>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Tanggal Register</label>
    <input name="tanggal_register"type="date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Ruang</label>
    <select name="ruang" class="form-control" id="exampleFormControlSelect1">
      @foreach($ruang as $ruang)
      <option value="{{$ruang->ruang}}">{{$ruang->ruang}}</option>
      @endforeach
    </select>
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Petugas</label>
    <select name="petugas" class="form-control" id="exampleFormControlSelect1">
      @foreach($petugas as $petugas)
      <option value="{{$petugas->petugas}}">{{$petugas->petugas}}</option>
      @endforeach
    </select>
  </div>
<div class="modal-footer">
	<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	<button type="submit" class="btn btn-primary">Submit</button>


</form>
@endsection

