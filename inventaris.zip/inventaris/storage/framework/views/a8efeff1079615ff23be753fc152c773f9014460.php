<!DOCTYPE html>
<html>
<head>
  <title>Edit Data Siswa</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

</head>
<body>

<div class="panel">
                <div class="panel-heading">
                  <h3 class="panel-title">Update Data Inventaris</h3>
                </div>
                <div class="panel-body">
                  <form action="/inventaris/<?php echo e($inventaris->id); ?>/update" method="POST">
              <?php echo e(csrf_field()); ?>

  <div class="form-group">
    <label for="exampleInputEmail1">Nama</label>
    <input name="nama"type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
    value="<?php echo e($inventaris->nama); ?>">
  </div>
   <div class="form-group">
    <label for="exampleInputEmail1">Kondisi</label>
    <input name="kondisi"type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($inventaris->kondisi); ?>">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Keterangan</label>
    <input name="keterangan"type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
    value="<?php echo e($inventaris->keterangan); ?>">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Jumlah</label>
    <input name="Jumlah"type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
    value="<?php echo e($inventaris->jumlah); ?>">
  </div>
   <div class="form-group">
    <label for="exampleFormControlSelect1">Jenis</label>
    <select name="jenis" class="form-control" id="exampleFormControlSelect1">
     <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($jenis->id_jenis); ?>"
        <?php if($inventaris->jenis == $jenis->jenis): ?>
        selected
        <?php endif; ?>>
        ><?php echo e($jenis->jenis); ?>

      </option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Ruang</label>
    <select name="ruang" class="form-control" id="exampleFormControlSelect1">
     <?php $__currentLoopData = $ruang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($ruang->id_ruang); ?>"
        <?php if($inventaris->ruang == $ruang->ruang): ?>
        selected
        <?php endif; ?>>
        ><?php echo e($ruang->ruang); ?>

      </option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Petugas</label>
    <select name="petugas" class="form-control" id="exampleFormControlSelect1">
     <?php $__currentLoopData = $petugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $petugas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($petugas->id_petugas); ?>"
        <?php if($inventaris->petugas == $petugas->petugas): ?>
        selected
        <?php endif; ?>>
        ><?php echo e($petugas->petugas); ?>

      </option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="modal-footer">
  
  <button type="submit" class="btn btn-warning">Update</button>

</div>
</form>
                </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>

 <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\inventaris\resources\views/inventaris/edit.blade.php ENDPATH**/ ?>