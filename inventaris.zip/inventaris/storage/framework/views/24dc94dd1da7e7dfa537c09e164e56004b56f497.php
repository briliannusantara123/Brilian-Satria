							


<?php $__env->startSection('content'); ?>
		<div class="row">
			<div class="col-6">
			<h3 class="panel-title">Data Inventaris</h3>
		</div>
		<div class="col-6">
			
		</div>
					<div class="col-md-12">

						<div class="panel">
				
							<div class="panel-heading">
									
									<div class="right">
									
									</div>
									
								</div>
                <br>
                <br>
                <br>
								<div class="panel-body">
                  <button type="button" class="btn btn-primary float-right btn-sm" data-toggle="modal" data-target="#exampleModal">Masukan Data inventaris</button>
									<table class="table table-hover">
										<thead>
											<tr>
												<th>Nama</th>
												<th>Kondisi</th>
												<th>Keterangan</th>
                        <th>Jumlah</th>
                        <th>Jenis</th>
                        <th>Tanggal Register</th>
                        <th>Ruang</th>
                        <th>Petugas</th>
												<th>Aksi</th>
											</tr>
										</thead>
										<tbody>
											<?php $__currentLoopData = $data_inventaris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventaris): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><?php echo e($inventaris->nama); ?></td>
												<td><?php echo e($inventaris->kondisi); ?></td>
												<td><?php echo e($inventaris->keterangan); ?></td>
                        <td><?php echo e($inventaris->jumlah); ?></td>
                        <td><?php echo e($inventaris->jenis); ?></td>
                        <td><?php echo e($inventaris->tanggal_register); ?></td>
                        <td><?php echo e($inventaris->ruang); ?></td>
                        <td><?php echo e($inventaris->petugas); ?></td>
												<td><a href="/inventaris/<?php echo e($inventaris->id); ?>/edit" class="btn btn-warning btn-sm">Edit</a>
													<a href="/inventaris/<?php echo e($inventaris->id); ?>/delete" class="btn btn-danger btn-sm" onclick ="return confirm('yakin akan menghapus data?')">Hapus</a>
												</td>
											</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
						</div>
	
						<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Inventaris</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
				        <form action="/inventaris/create" method="POST">
				      <?php echo e(csrf_field()); ?>

  
  <div class="form-group">
    <label for="exampleInputEmail1">Nama</label>
    <input name="nama"type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">

  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Kondisi</label>
    <input name="kondisi"type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Keterangan</label>
    <textarea name="keterangan"type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"></textarea>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Jumlah</label>
    <input name="jumlah"type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Jenis</label>
    <select name="jenis" class="form-control" id="exampleFormControlSelect1">
      <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($jenis->jenis); ?>"><?php echo e($jenis->jenis); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Tanggal Register</label>
    <input name="tanggal_register"type="date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Ruang</label>
    <select name="ruang" class="form-control" id="exampleFormControlSelect1">
      <?php $__currentLoopData = $ruang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($ruang->ruang); ?>"><?php echo e($ruang->ruang); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Petugas</label>
    <select name="petugas" class="form-control" id="exampleFormControlSelect1">
      <?php $__currentLoopData = $petugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $petugas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($petugas->petugas); ?>"><?php echo e($petugas->petugas); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
<div class="modal-footer">
	<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	<button type="submit" class="btn btn-primary">Submit</button>


</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\inventaris\resources\views/inventaris/index.blade.php ENDPATH**/ ?>