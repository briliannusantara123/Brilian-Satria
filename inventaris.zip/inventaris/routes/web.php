<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/inventaris','InventarisController@index');
Route::post('/inventaris/create','InventarisController@create');
Route::get('/inventaris/{id}/edit','InventarisController@edit');
Route::post('/inventaris/{id}/update','InventarisController@update');
Route::get('/inventaris/{id}/delete','InventarisController@delete');
Route::get('/jenis','JenisController@index');
Route::post('/jenis/create','JenisController@create');
Route::get('/jenis/{id}/edit','JenisController@edit');
Route::post('/jenis/{id}/update','JenisController@update');
Route::get('/jenis/{id}/delete','JenisController@delete');
Route::get('/ruang','RuangController@index');
Route::post('/ruang/create','RuangController@create');
Route::get('/ruang/{id}/edit','RuangController@edit');
Route::post('/ruang/{id}/update','RuangController@update');
Route::get('/ruang/{id}/delete','RuangController@delete');
Route::get('/petugas','PetugasController@index');
Route::post('/petugas/create','PetugasController@create');
Route::get('/petugas/{id}/edit','PetugasController@edit');
Route::post('/petugas/{id}/update','PetugasController@update');
Route::get('/petugas/{id}/delete','PetugasController@delete');
Route::get('/level','LevelController@index');
Route::post('/level/create','LevelController@create');
Route::get('/level/{id}/edit','LevelController@edit');
Route::post('/level/{id}/update','LevelController@update');
Route::get('/level/{id}/delete','LevelController@delete');
Route::get('/pegawai','PegawaiController@index');
Route::post('/pegawai/create','PegawaiController@create');
Route::get('/pegawai/{id}/edit','PegawaiController@edit');
Route::post('/pegawai/{id}/update','PegawaiController@update');
Route::get('/pegawai/{id}/delete','PegawaiController@delete');
Route::get('/peminjaman','PeminjamanController@index');
Route::post('/peminjaman/create','PeminjamanController@create');
Route::get('/peminjaman/{id}/edit','PeminjamanController@edit');
Route::post('/peminjaman/{id}/update','PeminjamanController@update');
Route::get('/peminjaman/{id}/delete','PeminjamanController@delete');